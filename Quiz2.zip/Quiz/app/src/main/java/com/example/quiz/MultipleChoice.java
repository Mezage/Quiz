package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class MultipleChoice extends AppCompatActivity {
    private int sec = 0, bigSec = 0;
    private boolean running = true;

    public void onClickSubmit(View view){           //when button clicked, check spinner input
        Intent intent;

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String choice = String.valueOf(spinner.getSelectedItem());

        if (!choice.equals("They cropped in another person's arm for the scenes")){
            intent = new Intent(this, Results.class);
            intent.putExtra(Results.FAILED, true);
        }else {
            intent = new Intent(this, ShortAnswer.class);
            intent.putExtra(ShortAnswer.newBig, bigSec);
        }
        startActivity(intent);
    }

    private void bigTimer(){                     //overall time
        TextView overall = (TextView) findViewById(R.id.overallTime);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = bigSec/3600;
                int min = (bigSec % 3600)/60;
                int seconds = bigSec % 60;
                String time = String.format("Overall time: %d:%02d:%02d", hours, min, seconds);

                overall.setText(time);
                bigSec++;
                handler.postDelayed(this, 1000);    //wait a sec before running again
            }
        });
    }

    private void smallTimer(){                  //for questions
        final TextView overall = (TextView) findViewById(R.id.questionTime);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = sec/3600;
                int min = (sec % 3600)/60;
                int seconds = sec % 60;
                String time = String.format("Question time: %d:%02d:%02d", hours, min, seconds);

                overall.setText(time);
                if (running){
                    sec++;}
                handler.postDelayed(this, 1000);    //wait a sec before running again
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("secs", sec);
        savedInstanceState.putInt("bigSecs", bigSec);
        savedInstanceState.putBoolean("run", running);
    }

    @Override
    protected void onPause(){       //when activity isn't in foreground
        super.onPause();
        running = false;
    }

    @Override
    protected void onResume(){      //when comes back into focus
        super.onResume();
        running = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null){
            sec = savedInstanceState.getInt("secs");
            bigSec = savedInstanceState.getInt("bigSecs");
            running = savedInstanceState.getBoolean("run");
        }
        smallTimer();
        bigTimer();
    }
}