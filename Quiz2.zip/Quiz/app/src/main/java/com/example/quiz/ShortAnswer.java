package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ShortAnswer extends AppCompatActivity {
    static int counter = 0;
    private boolean running = true;
    private int sec = 0, bigSec = 0;
    public static final String newBig = "NEWBIG";

    public void onClickSubmit(View view) {
        Intent intent = new Intent(this, Results.class);
        if (counter < 2) {
            EditText input = (EditText) findViewById(R.id.fruitInput);
            String answer2 = input.getText().toString();

            if (answer2.equalsIgnoreCase("peach")) {
                intent.putExtra(Results.FAILED, false);
                startActivity(intent);
            }
            counter++;
        }if(counter == 2) {
            intent.putExtra(Results.FAILED, true);
            startActivity(intent);
        }
    }

    private void bigTimer(){
        TextView overall = (TextView) findViewById(R.id.overallTime2);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = bigSec/3600;
                int min = (bigSec % 3600)/60;
                int seconds = bigSec % 60;
                String time = String.format("Overall time: %d:%02d:%02d", hours, min, seconds);

                overall.setText(time);
                bigSec++;
                handler.postDelayed(this, 1000);    //wait a sec before running again
            }
        });
    }

    private void smallTimer(){
        final TextView overall = (TextView) findViewById(R.id.questionTime2);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = sec/3600;
                int min = (sec % 3600)/60;
                int seconds = sec % 60;
                String time = String.format("Question time: %d:%02d:%02d", hours, min, seconds);

                overall.setText(time);
                if (running){
                    sec++;}
                handler.postDelayed(this, 1000);    //wait a sec before running again
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("secs", sec);
        savedInstanceState.putInt("bigSecs", bigSec);
        savedInstanceState.putInt("tries", counter);    //so user doesn't cheat
    }

    @Override
    protected void onPause(){       //when activity isn't in foreground
        super.onPause();
        running = false;
    }

    @Override
    protected void onResume(){      //when comes back into focus
        super.onResume();
        running = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short_answer);

        Intent intent = getIntent();                //grab the global timer from last activity
        bigSec = intent.getIntExtra(newBig, 0);
        counter = 0;                                //reset number of tries every time its loaded up

        if (savedInstanceState != null){
            sec = savedInstanceState.getInt("secs");
            bigSec = savedInstanceState.getInt("bigSecs");
            counter = savedInstanceState.getInt("tries");
        }
        smallTimer();
        bigTimer();
    }
}