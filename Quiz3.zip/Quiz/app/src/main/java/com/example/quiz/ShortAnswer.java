package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ShortAnswer extends AppCompatActivity {
    static int counter = 0, timer = -1;
    private boolean running = true, big, small, stylized;
    private int sec = 0, bigSec = 0;
    public static final String newBig = "NEWBIG";
    public static final String togW = "worldToggle";
    public static final String togQ = "questionToggle";
    public static final String limit = "timeLimit";
    public static final String style = "ButtonStyle";

    public void onClickSubmit(View view) {
        Intent intent = new Intent(this, Results.class);
        if (counter < 2) {
            EditText input = (EditText) findViewById(R.id.fruitInput);
            String answer2 = input.getText().toString();

            if (answer2.equalsIgnoreCase("peach")) {
                intent.putExtra(Results.FAILED, false);
                startActivity(intent);
            }
            counter++;
        }if(counter == 2) {
            intent.putExtra(Results.FAILED, true);
            startActivity(intent);
        }
    }

    private void bigTimer(){
        TextView overall = (TextView) findViewById(R.id.overallTime2);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = bigSec/3600;
                int min = (bigSec % 3600)/60;
                int seconds = bigSec % 60;
                String time = String.format("Overall time: %d:%02d:%02d", hours, min, seconds);

                overall.setText(time);
                bigSec++;
                handler.postDelayed(this, 1000);    //wait a sec before running again
            }
        });
    }

    private void smallTimer(){
        final TextView overall = (TextView) findViewById(R.id.questionTime2);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = sec/3600;
                int min = (sec % 3600)/60;
                int seconds = sec % 60;
                String time = String.format("Question time: %d:%02d:%02d", hours, min, seconds);

                if (small) {                        //if small is toggles, update text view
                    overall.setText(time);
                }
                if(timer != -1 && timer == sec){     //if there's a timer, check to see if time's up
                    Intent intent = new Intent(ShortAnswer.this, Results.class);
                    intent.putExtra(Results.FAILED, true);
                    startActivity(intent);
                    //finish();
                    //handler.removeCallbacksAndMessages(null);
                }else {
                    if (running){
                        sec++;}
                    handler.postDelayed(this, 1000);    //wait a sec before running again
                }
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("secs", sec);
        savedInstanceState.putInt("bigSecs", bigSec);
        savedInstanceState.putInt("tries", counter);    //so user doesn't cheat
        savedInstanceState.putBoolean("big",big);
        savedInstanceState.putBoolean("small", small);
        savedInstanceState.putInt("timer", timer);
    }

    @Override
    protected void onPause(){       //when activity isn't in foreground
        super.onPause();
        running = false;
    }

    @Override
    protected void onResume(){      //when comes back into focus
        super.onResume();
        running = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_short_answer);

        Intent intent = getIntent();                //grab the global timer from last activity
        bigSec = intent.getIntExtra(newBig, 0);
        counter = 0;                                //reset number of tries every time its loaded up

        small = intent.getBooleanExtra(togQ, false);
        big = intent.getBooleanExtra(togW, false);
        timer = intent.getIntExtra(limit, -1);
        stylized = intent.getBooleanExtra(style, false);

        if (savedInstanceState != null){
            sec = savedInstanceState.getInt("secs");
            bigSec = savedInstanceState.getInt("bigSecs");
            counter = savedInstanceState.getInt("tries");
            big = savedInstanceState.getBoolean("big");
            small = savedInstanceState.getBoolean("small");
            timer = savedInstanceState.getInt("timer");
            stylized = savedInstanceState.getBoolean("style");
        }

        if (small || (timer != -1)) {
            smallTimer();
        }if (big) {
            bigTimer();
        }if(stylized){                  //if stylized button, set normal button to gone
            findViewById(R.id.button2).setVisibility(View.GONE);
        }else{
            findViewById(R.id.imButt2).setVisibility(View.GONE);
        }
    }
}